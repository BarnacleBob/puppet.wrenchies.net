# You should look at interface_spec.rb
