#!/usr/bin/env rspec
require 'spec_helper'
require 'puppet/face'

describe Puppet::Face[:key, '0.0.1'] do
  it "should actually have some tests..."
end
