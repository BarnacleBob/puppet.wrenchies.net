class Symbol
  def as_json(options = nil) #:nodoc:
    to_s
  end
end
