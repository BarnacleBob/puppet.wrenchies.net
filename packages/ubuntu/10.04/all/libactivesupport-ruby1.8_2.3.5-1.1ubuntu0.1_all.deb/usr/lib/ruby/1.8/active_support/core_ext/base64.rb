require 'active_support/base64'
require 'active_support/core_ext/base64/encoding'

ActiveSupport::Base64.extend ActiveSupport::CoreExtensions::Base64::Encoding
