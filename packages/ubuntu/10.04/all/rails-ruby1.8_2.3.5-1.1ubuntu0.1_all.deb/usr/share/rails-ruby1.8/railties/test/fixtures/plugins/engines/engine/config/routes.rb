ActionController::Routing::Routes.draw do |map|
  map.connect '/engine', :controller => "engine"
end
