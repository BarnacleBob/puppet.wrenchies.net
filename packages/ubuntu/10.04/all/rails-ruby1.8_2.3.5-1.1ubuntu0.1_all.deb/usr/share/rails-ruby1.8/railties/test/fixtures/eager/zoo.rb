class Zoo
  include ReptileHouse
end