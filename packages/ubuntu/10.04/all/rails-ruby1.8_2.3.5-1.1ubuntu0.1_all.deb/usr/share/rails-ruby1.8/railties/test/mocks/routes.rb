module ActionController
  module Routing
    class Routes
    end
  end
end
