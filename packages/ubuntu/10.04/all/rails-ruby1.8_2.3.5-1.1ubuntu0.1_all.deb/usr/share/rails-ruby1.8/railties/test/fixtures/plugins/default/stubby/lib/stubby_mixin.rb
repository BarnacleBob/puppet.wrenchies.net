module StubbyMixin
end
