class AGenerator < Rails::Generator::Base
  def manifest
  end
end
