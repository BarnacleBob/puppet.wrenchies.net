def helper
  @helper ||= ApplicationController.helpers
end

@controller = ApplicationController.new
