class <%= controller_class_name %>Controller < ApplicationController
end
