# Alias to ensure old public.html still works.
RailsInfoController = Rails::InfoController
