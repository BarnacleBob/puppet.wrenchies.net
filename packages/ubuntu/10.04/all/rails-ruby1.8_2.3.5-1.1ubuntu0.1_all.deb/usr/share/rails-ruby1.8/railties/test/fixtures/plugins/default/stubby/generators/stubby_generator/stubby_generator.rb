class StubbyGenerator < Rails::Generator::Base
  def manifest
  end
end
