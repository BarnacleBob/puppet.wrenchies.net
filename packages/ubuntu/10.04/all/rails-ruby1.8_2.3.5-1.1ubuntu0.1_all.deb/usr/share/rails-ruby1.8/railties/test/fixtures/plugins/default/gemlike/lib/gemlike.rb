module Gemlike
end