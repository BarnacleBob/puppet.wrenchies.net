class <%= class_name %>Observer < ActiveRecord::Observer
end
