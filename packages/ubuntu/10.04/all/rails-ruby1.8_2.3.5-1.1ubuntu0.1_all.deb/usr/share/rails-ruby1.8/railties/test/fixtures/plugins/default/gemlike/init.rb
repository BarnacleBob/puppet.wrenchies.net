raise 'This init.rb should not be evaluated because rails/init.rb exists'
