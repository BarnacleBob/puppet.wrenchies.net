class WorkingGenerator < Rails::Generator::NamedBase
end
