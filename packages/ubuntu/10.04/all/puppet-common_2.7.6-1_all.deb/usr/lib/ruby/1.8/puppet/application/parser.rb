require 'puppet/application/face_base'
require 'puppet/face'

class Puppet::Application::Parser < Puppet::Application::FaceBase
end
