require 'puppet/indirector/store_configs'
require 'puppet/node'

class Puppet::Node::StoreConfigs < Puppet::Indirector::StoreConfigs
end
