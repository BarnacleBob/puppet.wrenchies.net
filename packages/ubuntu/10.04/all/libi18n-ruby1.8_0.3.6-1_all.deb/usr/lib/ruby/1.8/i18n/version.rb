module I18n
  VERSION = "0.3.6"
end