module I18n
  module Helpers
    autoload :Gettext, 'i18n/helpers/gettext'
  end
end
